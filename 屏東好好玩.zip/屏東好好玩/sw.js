// 屏東好好玩 - Service Worker
// 快取策略：
// - index.html / data.js：優先用網路上的最新版本，抓不到（離線）才用快取
// - 圖片、icon：優先用快取（不常變動），加快載入速度
const CACHE_NAME = 'pingtung-haohaowan-v1';

const APP_SHELL = [
  './',
  './index.html',
  './data.js',
  './manifest.json',
  './images/logo.png',
  './images/lighthouse.png',
  './images/victory-village.png',
  './images/cruise.png',
  './images/turtle.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const isCoreDoc = req.url.endsWith('/') || req.url.endsWith('index.html') || req.url.endsWith('data.js');

  if (isCoreDoc) {
    // network-first：確保票券資料與版面更新後，使用者能盡快看到最新版
    event.respondWith(
      fetch(req)
        .then(res => {
          const resClone = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(req, resClone));
          return res;
        })
        .catch(() => caches.match(req))
    );
  } else {
    // cache-first：圖片、icon 等靜態資源
    event.respondWith(
      caches.match(req).then(cached => cached || fetch(req).then(res => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(req, resClone));
        return res;
      }))
    );
  }
});
